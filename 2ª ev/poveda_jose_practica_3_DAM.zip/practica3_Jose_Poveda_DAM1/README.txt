// Una carpeta contiene solo MainWindow.xaml, MainWindow.xaml.cs y la clase objeto creada Persona.cs

// la carpeta todo tiene un zip con toda mi carpeta del proyecto

Saludos.

Jose Poveda DAM1 :)